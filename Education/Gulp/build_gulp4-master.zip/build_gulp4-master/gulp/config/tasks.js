module.exports = [
    './gulp/tasks/pug',
    './gulp/tasks/serve',
    './gulp/tasks/sass',
    './gulp/tasks/watch',
    './gulp/tasks/script',
    './gulp/tasks/img',
    './gulp/tasks/fonts',
    './gulp/tasks/svg'
];
