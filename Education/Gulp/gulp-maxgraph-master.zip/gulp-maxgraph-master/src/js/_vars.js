export default {
  $window: window,
  $document: document,
  $html: document.documentElement,
  $body: document.body,
}
