import testModule from './modules/module';

testModule('Billy');