export default function testModule(name) {
	console.log(`Name is ${name}`);
}