# Starter kit (gulp 4 / pug / postcss / webpack)

## Install dependencies
```bash
npm install
```

## Compiles / hot-reloads / sourcemaps

```bash
npm run dev
```

## Production build

```bash
npm run prod
```