"use strict";

console.log('hello inner');