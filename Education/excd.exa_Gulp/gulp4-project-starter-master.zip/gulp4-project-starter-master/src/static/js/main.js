$(document).ready(()=>{
  $('.slider').slick();
});