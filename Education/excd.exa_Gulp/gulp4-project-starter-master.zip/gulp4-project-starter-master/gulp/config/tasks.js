module.exports = [
  './gulp/tasks/pug',
  './gulp/tasks/sass',
  './gulp/tasks/watch',
  './gulp/tasks/serve',
  './gulp/tasks/script',
  './gulp/tasks/imgmin',
  './gulp/tasks/svg',
  './gulp/tasks/clean',
];