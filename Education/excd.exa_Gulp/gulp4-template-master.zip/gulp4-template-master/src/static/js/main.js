$(document).ready(() => {
    $('.slider').slick({

    })
});