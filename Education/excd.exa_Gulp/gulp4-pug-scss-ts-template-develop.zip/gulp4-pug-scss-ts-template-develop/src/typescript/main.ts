// Place your content here🐈
const message: string = "Hello World!";
console.log(message);
