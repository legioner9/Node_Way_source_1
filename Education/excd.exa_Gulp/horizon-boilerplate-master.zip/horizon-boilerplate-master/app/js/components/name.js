class Name {
    static sayName(name) {
        return `Hi, I am ${name}`;
    }
}

export default Name;
