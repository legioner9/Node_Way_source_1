# Стартовый шаблон автора канала FrontCoder
Используется связка `Gulp` + `Pug` + `SCSS` + `BrowserSync`

## Установка
Склонировать репозиторий и выполнить либо npm install

## Каналы связи
- [youtube канал](https://www.youtube.com/c/frontcoder)
- [чат в телеграм](https://t.me/frontcoder)
