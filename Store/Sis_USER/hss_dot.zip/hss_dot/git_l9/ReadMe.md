## `~/.ssh/git_l9/id_rsa` и `~/.ssh/git_l9/id_rsa.pub`

    ls -al ~/.ssh

    ssh-keygen -t rsa -b 4096 -C "legioner9@inbox.ru"

    Enter file in which to save the key (/c/Users/79953/.ssh/id_rsa):/c/Users/79953/.ssh/git_l9/id_rsa

    eval $(ssh-agent -s)

    $ ssh-add ~/.ssh/git_l9/id_rsa

    clip < ~/.ssh/git_l9/id_rsa.pub

    ssh -T git@github.com

    
    

    