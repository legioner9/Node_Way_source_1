```

workaday command

[git log -p v1]
[git diff brn v1]
[git switch -] (go to previous branch)
[git reset head~] (is opposite to command [ga v1]|[gc v1 -m v1=cnt_6])
[git reset --soft head] (is opposite to command [gc v1 -m v1=cnt_6])
[git reset --hard head~] (is opposite to command [echo cnt_6 > v1]|[ga v1]|[gc v1 -m v1=cnt_6])
[git restore v1] (is is opposite to command [echo rest > v1], in index cashed v1:cnt_6 after [ga v1])
[git restore -S<--staged> fun] (is is opposite to command [ga fun])
{   [gb]
        <>* brn
        master


    [gk]
        <> $$ bd7b93d: brn: -> v1=cnt_6{{v1:@@ -1 +1 @@
                                             -cnt_3
                                            +cnt_6}}
            $$ 6f97660: brn: -> v1=cnt_2{{v1:@@ -1 +1 @@
                                             -cnt_1
                                            +cnt_3}}
    [git revert head]
        <>[brn bc8c162] Revert "v1=cnt_6"

    [gk]
        <> $$ bc8c162: brn: -> Revert "v1=cnt_6"{{v1:@@ -1 +1 @@
                                             -cnt_6
                                            +cnt_3}}
        $$ bd7b93d: brn: -> v1=cnt_6{{v1:@@ -1 +1 @@
                                             -cnt_3
                                            +cnt_6}}
        $$ 6f97660: brn: -> v1=cnt_2{{v1:@@ -1 +1 @@
                                             -cnt_1
                                            +cnt_3}}
    [cat v1]
        <> cat_3
    
    }
[git revert head] = {[echo cnt_3 > v1]|[gc -m 'Revert "v1=cnt_6"']}

[]
    <> from command
    $ from gs
    $$ from gk
    * from gg

[echo cnt_0 > v1]
    $Untracked files: {{v1:cnt_0}}

[git add v1]
    $Changes to be committed:{{new file:   v1:cnt_0}}

        backward:[git rm --cached v1]  
                    <>rm 'v1'
                    $Untracked files: {{v1:cnt_0}}

[echo cnt_1 > v1]
    $Changes to be committed:{{new file:   v1:cnt_0}}
    $Changes not staged for commit:{{modified:   v1:cnt_1}}

        backward:[git restore v1]
                    $nothing to commit, working tree clean{{v1:cnt_0}}


[git commit -m v1=cnt_0]
    <>[master (root-commit) 74779f5] v1=cnt_0
        1 file changed, 1 insertion(+)
        create mode 100644 v1
    $ Changes not staged for commit:{{modified:   v1}}

    $$ not checked in to index{{v1:@@ -1 +1 @@
                                -cnt_0
                                +cnt_1}}
    * 74779f5 - (9 minutes ago) v1=cnt_0 - Legioner9 (HEAD -> master){{v1:@@ -0,0 +1 @@
                                                                                +cnt_0}}

[git add v1]
    $ Changes to be committed:{{modified:   v1}}
    $$ in to index but not committed{{v1:@@ -1 +1 @@
                                            -cnt_0
                                            +cnt_1}}
    * 74779f5 - (12 hours ago) v1=cnt_0 - Legioner9 (HEAD -> master){{v1:@@ -0,0 +1 @@
                                                                            +cnt_0}}
[echo cnt_2 > v1]
    $ Changes to be committed:{{modified:   v1}}
    $ Changes not staged for commit:{{modified:   v1}}
    $$ not checked in to index{{@@ -1 +1 @@
                                    -cnt_1
                                    +cnt_2}}
    $$ checked in to index but not committed{{v1:@@ -1 +1 @@
                                                    -cnt_0
                                                    +cnt_1}}
    * 74779f5 - (12 hours ago) v1=cnt_0 - Legioner9 (HEAD -> master){{v1:@@ -0,0 +1 @@
                                                                            +cnt_0}}               
[git remote add bare ../bare/]
[git push bare master]
    $ Changes to be committed:{{modified:   v1}}
    $ Changes not staged for commit:{{modified:   v1}}
    $$ not checked in to index{{@@ -1 +1 @@
                                    -cnt_1
                                    +cnt_2}}
    $$ checked in to index but not committed{{v1:@@ -1 +1 @@
                                                    -cnt_0
                                                    +cnt_1}}
    * 74779f5 - (13 hours ago) v1=cnt_0 - Legioner9 (HEAD -> master, bare/master){{v1:@@ -0,0 +1 @@
                                                                                        +cnt_0}}
[git commit -m v1=cnt_1]
    <>[master 4016163] v1=cnt_1
    1 file changed, 1 insertion(+), 1 deletion(-)
    $ Changes not staged for commit:{{modified:   v1}}
    $$ not checked in to index{{v1:@@ -1 +1 @@
                                    -cnt_1
                                    +cnt_2}}

* 4016163 - (2 minutes ago) v1=cnt_1 - Legioner9 (HEAD -> master){{v1:@@ -1 +1 @@
                                                    -cnt_0
                                                    +cnt_1}}
* 74779f5 - (13 hours ago) v1=cnt_0 - Legioner9 (bare/master){{v1:@@ -0,0 +1 @@
                                                                    +cnt_0}}

[git add v1]
    $ Changes to be committed:{{modified:   v1}}
    $$ checked in to index but not committed{{v1:@@ -1 +1 @@
                                    -cnt_1
                                    +cnt_2}}

* 4016163 - (2 minutes ago) v1=cnt_1 - Legioner9 (HEAD -> master){{v1:@@ -1 +1 @@
                                                    -cnt_0
                                                    +cnt_1}}
* 74779f5 - (13 hours ago) v1=cnt_0 - Legioner9 (bare/master){{v1:@@ -0,0 +1 @@
                                                                    +cnt_0}}

[echo cnt_3 > v1]
    $ Changes to be committed:{{modified:   v1}}
    $ Changes not staged for commit:{{modified:   v1}}
    $$ not checked in to index{{@@ -1 +1 @@
                                    -cnt_2
                                    +cnt_3}}
    $$ checked in to index but not committed{{v1:@@ -1 +1 @@
                                                    -cnt_1
                                                    +cnt_2}}

* 4016163 - (2 minutes ago) v1=cnt_1 - Legioner9 (HEAD -> master){{v1:@@ -1 +1 @@
                                                    -cnt_0
                                                    +cnt_1}}
* 74779f5 - (13 hours ago) v1=cnt_0 - Legioner9 (bare/master){{v1:@@ -0,0 +1 @@
                                                                      +cnt_0}}                                                    
[echo cnt_un > fun]
[cat fun]
    <>cnt_un
    $ Changes to be committed:{{modified:   v1}}
    $ Changes not staged for commit:{{modified:   v1}}
    $ Untracked files:{{fun}}
    $$ not checked in to index{{@@ -1 +1 @@
                                    -cnt_2
                                    +cnt_3}}
    $$ checked in to index but not committed{{v1:@@ -1 +1 @@
                                                    -cnt_1
                                                    +cnt_2}}

* 4016163 - (2 minutes ago) v1=cnt_1 - Legioner9 (HEAD -> master){{v1:@@ -1 +1 @@
                                                    -cnt_0
                                                    +cnt_1}}
* 74779f5 - (13 hours ago) v1=cnt_0 - Legioner9 (bare/master){{v1:@@ -0,0 +1 @@
                                                                      +cnt_0}}


```






