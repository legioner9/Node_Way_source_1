------------------------------------------------------------------------------
ON branch ...
[]
    <>
    ON branch ...
    $ nothing to commit, working tree clean
    $ Changes to be committed:{{}}
    $ Changes not staged for commit:{{}}
    $ Untracked files:{{}}

    $$ not checked in to index{{file:}}
    $$ checked in to index but not committed{{file:}}

    $$ hash: Branch: -> Precedes:{{file:}}

------------------------------------------------------------------------------

        remaine[]
        <>
        ............

------------------------------------------------------------------------------

        reflex[]
        <>
        ............

------------------------------------------------------------------------------

------------------------------------------------------------------------------
ON branch ...
[]
    <>
    ON branch ...
    $ nothing to commit, working tree clean
    $ Changes to be committed:{{}}
    $ Changes not staged for commit:{{}}
    $ Untracked files:{{}}

    $$ not checked in to index{{file:}}
    $$ checked in to index but not committed{{file:}}

    $$ hash: Branch: -> Precedes:{{file:}}

------------------------------------------------------------------------------

        remaine[]
        <>
        ............

------------------------------------------------------------------------------

        reflex[]
        <>
        ............

------------------------------------------------------------------------------

------------------------------------------------------------------------------
ON branch ...
[]
    <>
    ON branch ...
    $ nothing to commit, working tree clean
    $ Changes to be committed:{{}}
    $ Changes not staged for commit:{{}}
    $ Untracked files:{{}}

    $$ not checked in to index{{file:}}
    $$ checked in to index but not committed{{file:}}

    $$ hash: Branch: -> Precedes:{{file:}}

------------------------------------------------------------------------------

        remaine[]
        <>
        ............

------------------------------------------------------------------------------

        reflex[]
        <>
        ............

------------------------------------------------------------------------------