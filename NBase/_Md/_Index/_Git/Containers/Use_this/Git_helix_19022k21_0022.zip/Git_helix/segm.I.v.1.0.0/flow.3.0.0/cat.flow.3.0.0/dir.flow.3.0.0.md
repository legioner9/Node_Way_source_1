- <a href = "F:\Node_projects\Node_Way\NBase\_Md\_Index\_Git\Containers\Use_this\Git_helix\segm.I.v.1.0.0\flow.3.0.0\cat.flow.3.0.0\dir.flow.3.0.0.md">flow.3.0.0</a>
    - <a href = "F:\Node_projects\Node_Way\NBase\_Md\_Index\_Git\Containers\Use_this\Git_helix\segm.I.v.1.0.0\flow.3.0.0\1.0.0\cat.1.0.0\dir.1.0.0.md">1.0.0</a>
        - <a href = "F:\Node_projects\Node_Way\NBase\_Md\_Index\_Git\Containers\Use_this\Git_helix\segm.I.v.1.0.0\flow.3.0.0\1.0.0\tag\cat.tag\dir.tag.md">tag</a>
            - <a href = "F:\Node_projects\Node_Way\NBase\_Md\_Index\_Git\Containers\Use_this\Git_helix\segm.I.v.1.0.0\flow.3.0.0\1.0.0\tag\tag.md">tag.md</a>
                - *## git show tag_lw
            - <a href = "F:\Node_projects\Node_Way\NBase\_Md\_Index\_Git\Containers\Use_this\Git_helix\segm.I.v.1.0.0\flow.3.0.0\1.0.0\tag\tag_a.md">tag_a.md</a>
                - *## git tag -a tag_0 -m create_tag_0
            - <a href = "F:\Node_projects\Node_Way\NBase\_Md\_Index\_Git\Containers\Use_this\Git_helix\segm.I.v.1.0.0\flow.3.0.0\1.0.0\tag\tag_a_hash.gh_tag.md">tag_a_hash.gh_tag.md</a>
                - *## git tag -a tag_0 -m create_tag_0
            - <a href = "F:\Node_projects\Node_Way\NBase\_Md\_Index\_Git\Containers\Use_this\Git_helix\segm.I.v.1.0.0\flow.3.0.0\1.0.0\tag\tag_a_hash.md">tag_a_hash.md</a>
                - *## git tag -a tag_0 -m create_tag_0
        
    
