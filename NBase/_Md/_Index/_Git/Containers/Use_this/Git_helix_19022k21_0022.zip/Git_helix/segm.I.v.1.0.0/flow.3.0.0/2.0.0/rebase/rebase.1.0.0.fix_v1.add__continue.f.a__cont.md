```
workaday command

[git log -p v1]
[git diff brn v1]
[git switch -] (go to previous branch)
[git reset head~] (is opposite to command [ga v1]|[gc v1 -m v1=cnt_6])
[git reset --soft head] (is opposite to command [gc v1 -m v1=cnt_6])
[git reset --hard head~] (is opposite to command [echo cnt_6 > v1]|[ga v1]|[gc v1 -m v1=cnt_6])
[git restore v1] (is is opposite to command [echo rest > v1], in index cashed v1:cnt_6 after [ga v1])
[git restore -S<--staged> fun] (is is opposite to command [ga fun])
{   [gb]
        <>* brn
        master


    [gk]
        <> $$ bd7b93d: brn: -> v1=cnt_6{{v1:@@ -1 +1 @@
                                             -cnt_3
                                            +cnt_6}}
            $$ 6f97660: brn: -> v1=cnt_2{{v1:@@ -1 +1 @@
                                             -cnt_1
                                            +cnt_3}}
    [git revert head]
        <>[brn bc8c162] Revert "v1=cnt_6"

    [gk]
        <> $$ bc8c162: brn: -> Revert "v1=cnt_6"{{v1:@@ -1 +1 @@
                                             -cnt_6
                                            +cnt_3}}
        $$ bd7b93d: brn: -> v1=cnt_6{{v1:@@ -1 +1 @@
                                             -cnt_3
                                            +cnt_6}}
        $$ 6f97660: brn: -> v1=cnt_2{{v1:@@ -1 +1 @@
                                             -cnt_1
                                            +cnt_3}}
    [cat v1]
        <> cat_3
    
    }
[git revert head] = {[echo cnt_3 > v1]|[gc -m 'Revert "v1=cnt_6"']}


=============================================

[go](../proj.2.0.0/SandBoxes/SpawningNewBranch/create.1.0.0_to_2.0.0/set.1.0.0._to.2.0.0.v.7/v1)
[init from](create.1.0.0_to_2.0.0.md)

[gh brn]
    <>Switched to branch 'brn'
[echo cnt_6 > v1]
[gc v1 -m v1=cnt_6]
    <>[brn bd7b93d] v1=cnt_6
    1 file changed, 1 insertion(+), 1 deletion(-)

    ON branch brn
    $ Untracked files:{{fun}} 

    $$ 057224d: master -> v1=cnt_5{{v1:@@ -1 +1 @@
                        -cnt_4
                        +cnt_5}}
    $$ 594d4a4: master -> v1=cnt_4{{v1:@@ -1 +1 @@
                        -cnt_1
                        +cnt_4}}
    $$ bd7b93d: brn: -> v1=cnt_6{{v1:@@ -1 +1 @@
                                             -cnt_3
                                            +cnt_6}}
    $$ 6f97660: brn: -> v1=cnt_2{{v1:@@ -1 +1 @@
                                             -cnt_1
                                            +cnt_3}}

    $$ 4016163: brn, master -> v1=cnt_1{{v1:@@ -1 +1 @@
                        -cnt_0
                        +cnt_1}}
    $$ 74779f5: master, remotes/bare/master -> v1=cnt_0{{v1:@@ -0,0 +1 @@
                                                        +cnt_0}}

* bd7b93d - (3 minutes ago) v1=cnt_6 - Legioner9 (HEAD -> brn)
* 6f97660 - (2 hours ago) v1=cnt_2 - Legioner9
| * 057224d - (16 minutes ago) v1=cnt_5 - Legioner9 (master)
| * 594d4a4 - (54 minutes ago) v1=cnt_4 - Legioner9
|/
* 4016163 - (9 days ago) v1=cnt_1 - Legioner9
* 74779f5 - (10 days ago) v1=cnt_0 - Legioner9 (bare/master)

------------------------------------------------------------------------------

        reflex[git diff bd7b93d 057224d]
            <>diff --git a/v1 b/v1
            index 9c91221..3b25212 100644
            --- a/v1
            +++ b/v1
            @@ -1 +1 @@
            -cnt_6
            +cnt_5

------------------------------------------------------------------------------
[go](F:\Node_projects\Node_Way\NBase\_Md\_Index\_Git\Containers\Use_this\Git_helix\segm.I.v.1.0.0\proj.2.0.0\SandBoxes\FlowRebase\set.2.0.0.rebase.1.0.0)
on branch brn
[git rebase master]
    <>First, rewinding head to replay your work on top of it...
    Applying: v1=cnt_2
    Using index info to reconstruct a base tree...
    M       v1
    Falling back to patching base and 3-way merge...
    Auto-merging v1
    CONFLICT (content): Merge conflict in v1
    error: Failed to merge in the changes.
    hint: Use 'git am --show-current-patch' to see the failed patch
    Patch failed at 0001 v1=cnt_2
    Resolve all conflicts manually, mark them as resolved with
    "git add/rm <conflicted_files>", then run "git rebase --continue".
    You can instead skip this commit: run "git rebase --skip".
    To abort and get back to the state before "git rebase", run "git rebase --abort".

    ON branch [(no branch, rebasing brn)]
    [gs]
        <> rebase in progress; onto 057224d
        You are currently rebasing branch 'brn' on '057224d'.
        (fix conflicts and then run "git rebase --continue")
        (use "git rebase --skip" to skip this patch)
        (use "git rebase --abort" to check out the original branch)

        Unmerged paths:
        (use "git restore --staged <file>..." to unstage)
        (use "git add <file>..." to mark resolution)
                both modified:   v1

        Untracked files:
        (use "git add <file>..." to include in what will be committed)
                fun

        no changes added to commit (use "git add" and/or "git commit -a")
        
    [cat v1]
        <><<<<<<< HEAD
        cnt_5
        =======
        cnt_3
        >>>>>>> v1=cnt_2


    $ Unmerged paths:{{both modified:   v1}}
    $ Untracked files:{{fun}}

    $$ not checked in to index{{v1:@@@ -1,1 -1,1 +1,5 @@@
                                                        ++<<<<<<< HEAD
                                                        +cnt_5
                                                        ++=======
                                                        + cnt_3
                                                        ++>>>>>>> v1=cnt_2}}
    $$ Unmerged path v1:<empty>

    $$ 057224d: master -> v1=cnt_5{{v1:@@ -1 +1 @@
                        -cnt_4
                        +cnt_5}}
    $$ 594d4a4: master -> v1=cnt_4{{v1:@@ -1 +1 @@
                        -cnt_1
                        +cnt_4}}
    $$ bd7b93d: brn: -> v1=cnt_6{{v1:@@ -1 +1 @@
                                             -cnt_3
                                            +cnt_6}}
    $$ 6f97660: brn: -> v1=cnt_2{{v1:@@ -1 +1 @@
                                             -cnt_1
                                            +cnt_3}}

    $$ 4016163: brn, master -> v1=cnt_1{{v1:@@ -1 +1 @@
                        -cnt_0
                        +cnt_1}}
    $$ 74779f5: master, remotes/bare/master -> v1=cnt_0{{v1:@@ -0,0 +1 @@
                                                        +cnt_0}}


------------------------------------------------------------------------------
ON branch [(no branch, rebasing brn)]
[echo cnt_5+3 > v1]
[ga v1]
    <>
    [gs]
        <>rebase in progress; onto 057224d
        You are currently rebasing branch 'brn' on '057224d'.
        (all conflicts fixed: run "git rebase --continue")

        Changes to be committed:
        (use "git restore --staged <file>..." to unstage)
                modified:   v1

        Untracked files:
        (use "git add <file>..." to include in what will be committed)
                fun

    ON branch [(no branch, rebasing brn)]
 
    $ Changes to be committed:{{modified:   v1}}
    $ Untracked files:{{fun}}

    $$ checked in to index but not committed{{v1:@@ -1 +1 @@
                                                -cnt_5
                                                +cnt_5+3}}
    $$ 057224d: master -> v1=cnt_5{{v1:@@ -1 +1 @@
                        -cnt_4
                        +cnt_5}}
    $$ 594d4a4: master -> v1=cnt_4{{v1:@@ -1 +1 @@
                        -cnt_1
                        +cnt_4}}
    $$ bd7b93d: brn: -> v1=cnt_6{{v1:@@ -1 +1 @@
                                             -cnt_3
                                            +cnt_6}}
    $$ 6f97660: brn: -> v1=cnt_2{{v1:@@ -1 +1 @@
                                             -cnt_1
                                            +cnt_3}}

    $$ 4016163: brn, master -> v1=cnt_1{{v1:@@ -1 +1 @@
                        -cnt_0
                        +cnt_1}}
    $$ 74779f5: master, remotes/bare/master -> v1=cnt_0{{v1:@@ -0,0 +1 @@
                                                        +cnt_0}}

------------------------------------------------------------------------------
[go](F:\Node_projects\Node_Way\NBase\_Md\_Index\_Git\Containers\Use_this\Git_helix\segm.I.v.1.0.0\proj.2.0.0\SandBoxes\FlowRebase\set.2.0.0.rebase.1.0.0.fix.add__continue)
[(no branch, rebasing brn)].
[git rebase --continue]
    <>Applying: v1=cnt_2
    Applying: v1=cnt_6
    Using index info to reconstruct a base tree...
    M       v1
    Falling back to patching base and 3-way merge...
    Auto-merging v1
    CONFLICT (content): Merge conflict in v1
    error: Failed to merge in the changes.
    hint: Use 'git am --show-current-patch' to see the failed patch
    Patch failed at 0002 v1=cnt_6
    Resolve all conflicts manually, mark them as resolved with
    "git add/rm <conflicted_files>", then run "git rebase --continue".
    You can instead skip this commit: run "git rebase --skip".
    To abort and get back to the state before "git rebase", run "git rebase --abort".
    [gs]
        <>rebase in progress; onto 057224d
        You are currently rebasing branch 'brn' on '057224d'.
        (fix conflicts and then run "git rebase --continue")
        (use "git rebase --skip" to skip this patch)
        (use "git rebase --abort" to check out the original branch)

        Unmerged paths:
        (use "git restore --staged <file>..." to unstage)
        (use "git add <file>..." to mark resolution)
                both modified:   v1

        Untracked files:
        (use "git add <file>..." to include in what will be committed)
                fun


    ON branch [(no branch, rebasing brn)]
    $ Unmerged paths:{{both modified:   v1}}
    $ Untracked files:{{fun}}


    $$ not checked in to index{{v1:@@@ -1,1 -1,1 +1,5 @@@
                                        ++<<<<<<< HEAD
                                        +cnt_5+3
                                        ++=======
                                        + cnt_6
                                        ++>>>>>>> v1=cnt_6}}

    $$ 92d5440: (no branch, rebasing brn): -> v1=cnt_2:{{v1:@@ -1 +1 @@
                                                            -cnt_5
                                                            +cnt_5+3}}
    $$ 057224d: master -> v1=cnt_5{{v1:@@ -1 +1 @@
                        -cnt_4
                        +cnt_5}}
    $$ 594d4a4: master -> v1=cnt_4{{v1:@@ -1 +1 @@
                        -cnt_1
                        +cnt_4}}
    $$ bd7b93d: brn: -> v1=cnt_6{{v1:@@ -1 +1 @@
                                             -cnt_3
                                            +cnt_6}}
    $$ 6f97660: brn: -> v1=cnt_2{{v1:@@ -1 +1 @@
                                             -cnt_1
                                            +cnt_3}}

    $$ 4016163: brn, master -> v1=cnt_1{{v1:@@ -1 +1 @@
                        -cnt_0
                        +cnt_1}}
    $$ 74779f5: master, remotes/bare/master -> v1=cnt_0{{v1:@@ -0,0 +1 @@
                                                        +cnt_0}}

------------------------------------------------------------------------------
[go](F:\Node_projects\Node_Way\NBase\_Md\_Index\_Git\Containers\Use_this\Git_helix\segm.I.v.1.0.0\proj.2.0.0\SandBoxes\FlowRebase\set.2.0.0.rebase.1.0.0.fix.add__continue.f.a.cont)
ON branch [(no branch, rebasing brn)]
[echo cnt_5+3++6 > v1]
[ga v1]
[git rebase --continue]
    <>Applying: v1=cnt_6

    ON branch [brn]
    $ Untracked files:{{fun}}

    $$ d8929c3: brn: -> v1=cnt_6:{{v1:@@ -1 +1 @@
                                            -cnt_5+3
                                            +cnt_5+3++6}}

    $$ 92d5440: brn: -> v1=cnt_2:{{v1:@@ -1 +1 @@
                                            -cnt_5
                                            +cnt_5+3}}
    $$ 057224d: master -> v1=cnt_5{{v1:@@ -1 +1 @@
                        -cnt_4
                        +cnt_5}}
    $$ 594d4a4: master -> v1=cnt_4{{v1:@@ -1 +1 @@
                        -cnt_1
                        +cnt_4}}
    $$ bd7b93d: brn: -> v1=cnt_6{{v1:@@ -1 +1 @@
                                             -cnt_3
                                            +cnt_6}}
    $$ 6f97660: brn: -> v1=cnt_2{{v1:@@ -1 +1 @@
                                             -cnt_1
                                            +cnt_3}}

    $$ 4016163: brn, master -> v1=cnt_1{{v1:@@ -1 +1 @@
                        -cnt_0
                        +cnt_1}}
    $$ 74779f5: master, remotes/bare/master -> v1=cnt_0{{v1:@@ -0,0 +1 @@
                                                        +cnt_0}}
    $$ not checked in to index{{file:}}
    $$ checked in to index but not committed{{file:}}

    $$ hash: Branch: -> Precedes:{{file:}}

* d8929c3 - (4 days ago) v1=cnt_6 - Legioner9 (HEAD -> brn)
* 92d5440 - (4 days ago) v1=cnt_2 - Legioner9
* 057224d - (4 days ago) v1=cnt_5 - Legioner9 (master)
* 594d4a4 - (4 days ago) v1=cnt_4 - Legioner9
* 4016163 - (13 days ago) v1=cnt_1 - Legioner9
* 74779f5 - (2 weeks ago) v1=cnt_0 - Legioner9 (bare/master)


------------------------------------------------------------------------------

        remaine[]
        <>
        ............

------------------------------------------------------------------------------

        reflex[]
        <>
        ............

```