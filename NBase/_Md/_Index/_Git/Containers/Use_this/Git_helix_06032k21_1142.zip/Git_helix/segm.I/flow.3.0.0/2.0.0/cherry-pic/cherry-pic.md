```
workaday command

[git log -p v1]
[git diff brn v1]
[git switch -] (go to previous branch)
[git reset head~] (is opposite to command [ga v1]|[gc v1 -m v1=cnt_6])
[git reset --soft head] (is opposite to command [gc v1 -m v1=cnt_6])
[git reset --hard head~] (is opposite to command [echo cnt_6 > v1]|[ga v1]|[gc v1 -m v1=cnt_6])
[git restore v1] (is is opposite to command [echo rest > v1], in index cashed v1:cnt_6 after [ga v1])
[git restore -S<--staged> fun] (is is opposite to command [ga fun])
{   [gb]
        <>* brn
        master


    [gk]
        <> $$ bd7b93d: brn: -> v1=cnt_6{{v1:@@ -1 +1 @@
                                             -cnt_3
                                            +cnt_6}}
            $$ 6f97660: brn: -> v1=cnt_2{{v1:@@ -1 +1 @@
                                             -cnt_1
                                            +cnt_3}}
    [git revert head]
        <>[brn bc8c162] Revert "v1=cnt_6"

    [gk]
        <> $$ bc8c162: brn: -> Revert "v1=cnt_6"{{v1:@@ -1 +1 @@
                                             -cnt_6
                                            +cnt_3}}
        $$ bd7b93d: brn: -> v1=cnt_6{{v1:@@ -1 +1 @@
                                             -cnt_3
                                            +cnt_6}}
        $$ 6f97660: brn: -> v1=cnt_2{{v1:@@ -1 +1 @@
                                             -cnt_1
                                            +cnt_3}}
    [cat v1]
        <> cat_3
    
    }
[git revert head] = {[echo cnt_3 > v1]|[gc -m 'Revert "v1=cnt_6"']}


=============================================

[go](../proj.2.0.0/SandBoxes/SpawningNewBranch/create.1.0.0_to_2.0.0/set.1.0.0._to.2.0.0.v.7/v1)
[init from](create.1.0.0_to_2.0.0.md)

[gh brn]
    <>Switched to branch 'brn'
[echo cnt_6 > v1]
[gc v1 -m v1=cnt_6]
    <>[brn bd7b93d] v1=cnt_6
    1 file changed, 1 insertion(+), 1 deletion(-)

    ON branch brn
    $ Untracked files:{{fun}} 

    $$ 057224d: master -> v1=cnt_5{{v1:@@ -1 +1 @@
                        -cnt_4
                        +cnt_5}}
    $$ 594d4a4: master -> v1=cnt_4{{v1:@@ -1 +1 @@
                        -cnt_1
                        +cnt_4}}
    $$ bd7b93d: brn: -> v1=cnt_6{{v1:@@ -1 +1 @@
                                             -cnt_3
                                            +cnt_6}}
    $$ 6f97660: brn: -> v1=cnt_2{{v1:@@ -1 +1 @@
                                             -cnt_1
                                            +cnt_3}}

    $$ 4016163: brn, master -> v1=cnt_1{{v1:@@ -1 +1 @@
                        -cnt_0
                        +cnt_1}}
    $$ 74779f5: master, remotes/bare/master -> v1=cnt_0{{v1:@@ -0,0 +1 @@
                                                        +cnt_0}}

* bd7b93d - (3 minutes ago) v1=cnt_6 - Legioner9 (HEAD -> brn)
* 6f97660 - (2 hours ago) v1=cnt_2 - Legioner9
| * 057224d - (16 minutes ago) v1=cnt_5 - Legioner9 (master)
| * 594d4a4 - (54 minutes ago) v1=cnt_4 - Legioner9
|/
* 4016163 - (9 days ago) v1=cnt_1 - Legioner9
* 74779f5 - (10 days ago) v1=cnt_0 - Legioner9 (bare/master)

------------------------------------------------------------------------------

        reflex[git diff bd7b93d 057224d]
            <>diff --git a/v1 b/v1
            index 9c91221..3b25212 100644
            --- a/v1
            +++ b/v1
            @@ -1 +1 @@
            -cnt_6
            +cnt_5

------------------------------------------------------------------------------

[]
    <>
    ON branch ...
    $ nothing to commit, working tree clean
    $ Changes to be committed:{{}}
    $ Changes not staged for commit:{{}}
    $ Untracked files:{{}}

    $$ not checked in to index{{file:}}
    $$ checked in to index but not committed{{file:}}

    $$ hash: Branch: -> Precedes:{{file:}}

------------------------------------------------------------------------------

[]
    <>
    ON branch ...
    $ nothing to commit, working tree clean
    $ Changes to be committed:{{}}
    $ Changes not staged for commit:{{}}
    $ Untracked files:{{}}

    $$ not checked in to index{{file:}}
    $$ checked in to index but not committed{{file:}}

    $$ hash: Branch: -> Precedes:{{file:}}

------------------------------------------------------------------------------

        remaine[]
        <>
        ............

------------------------------------------------------------------------------

        reflex[]
        <>
        ............

```