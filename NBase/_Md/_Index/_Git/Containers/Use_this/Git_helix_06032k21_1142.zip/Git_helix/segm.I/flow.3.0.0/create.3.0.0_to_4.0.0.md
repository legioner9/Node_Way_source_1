```

workaday command

[git log -p v1]
[git diff brn v1]
[git switch -] (go to previous branch)
[git reset head~] (is opposite to command [ga v1]|[gc v1 -m v1=cnt_6])
[git reset --soft head] (is opposite to command [gc v1 -m v1=cnt_6])
[git reset --hard head~] (is opposite to command [echo cnt_6 > v1]|[ga v1]|[gc v1 -m v1=cnt_6])
[git restore v1] (is is opposite to command [echo rest > v1], in index cashed v1:cnt_6 after [ga v1])
[git restore -S<--staged> fun] (is is opposite to command [ga fun])
{   [gb]
        <>* brn
        master


    [gk]
        <> $$ bd7b93d: brn: -> v1=cnt_6{{v1:@@ -1 +1 @@
                                             -cnt_3
                                            +cnt_6}}
            $$ 6f97660: brn: -> v1=cnt_2{{v1:@@ -1 +1 @@
                                             -cnt_1
                                            +cnt_3}}
    [git revert head]
        <>[brn bc8c162] Revert "v1=cnt_6"

    [gk]
        <> $$ bc8c162: brn: -> Revert "v1=cnt_6"{{v1:@@ -1 +1 @@
                                             -cnt_6
                                            +cnt_3}}
        $$ bd7b93d: brn: -> v1=cnt_6{{v1:@@ -1 +1 @@
                                             -cnt_3
                                            +cnt_6}}
        $$ 6f97660: brn: -> v1=cnt_2{{v1:@@ -1 +1 @@
                                             -cnt_1
                                            +cnt_3}}
    [cat v1]
        <> cat_3
    
    }
[git revert head] = {[echo cnt_3 > v1]|[gc -m 'Revert "v1=cnt_6"']}

------------------------------------------------------------------------------
[go]()


------------------------------------------------------------------------------

[]
    <>
    ON branch ...
    $ nothing to commit, working tree clean
    $ Changes to be committed:{{}}
    $ Changes not staged for commit:{{}}
    $ Untracked files:{{}}

    $$ not checked in to index{{file:}}
    $$ checked in to index but not committed{{file:}}

    $$ hash: Branch: -> Precedes:{{file:}}

------------------------------------------------------------------------------

ON branch ...
[]
    <>
    ON branch ...
    $ nothing to commit, working tree clean
    $ Changes to be committed:{{}}
    $ Changes not staged for commit:{{}}
    $ Untracked files:{{}}

    $$ not checked in to index{{file:}}
    $$ checked in to index but not committed{{file:}}

    $$ hash: Branch: -> Precedes:{{file:}}

------------------------------------------------------------------------------

        remaine[]
        <>
        ............

```