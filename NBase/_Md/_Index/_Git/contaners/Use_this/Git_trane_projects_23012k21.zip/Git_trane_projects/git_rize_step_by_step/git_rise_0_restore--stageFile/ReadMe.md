# delete file from index

    (*)
    {shape_6}={
        {st}={}
        {fs}={
            v1:'cng_2',
        }
        {ws}={
            v1:'cng_2',
        }
        {in}={
            v1:'cng_1',
        }
        {lr}={
            v1:'',
        }
        {ur}={}
        }
    (*)

## * git restore --staged \<file>
        {{in} dn {wd}}
            [git restore --staged v1]
                <>
            [cat v1]
                <>cng_2
                [gs]
                    <>Changes not staged for commit:
                    <>modified:   v1
                [gw]
                    <>*prev*
                [gg]
                    <>*prev*   
    (*)
    {shape_7}={
        {st}={}
        {fs}={
            v1:'cng_2',
        }
        {ws}={
            v1:'cng_2',
        }
        {in}={}
        {lr}={
            v1:'',
        }
        {ur}={}
        }
    (*)