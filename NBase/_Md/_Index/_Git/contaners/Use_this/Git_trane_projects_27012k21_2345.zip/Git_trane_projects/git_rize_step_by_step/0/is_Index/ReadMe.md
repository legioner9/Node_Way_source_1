    $ git remote add brr ../this_bare/
