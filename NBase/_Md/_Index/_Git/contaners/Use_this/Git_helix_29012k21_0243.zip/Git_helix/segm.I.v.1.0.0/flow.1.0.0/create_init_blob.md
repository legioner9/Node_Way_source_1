- alias gs="git status"
- alias gd="git add ."
- alias gp="git push -u origin master"
- alias gl="git log --pretty=format:\"%h %s\" --graph"
- alias gw="git show --stat --oneline HEAD"
- alias gg="git log --graph --abbrev-commit --decorate --date=relative --format=format:'%C(bold blue)%h%C(reset) - %C(bold green)(%ar)%C(reset) %C(white)%s%C(reset) %C(dim white)- %an%C(reset)%C(bold yellow)%d%C(reset)' --all"

    {shape_1}={
        {st}={}  
        {ws}={}
        {in}={}
        {lr}={}
        }
    (*)
        [touch v1]
            <>
            [gs]
                <>
            [gw]
                <>
            [gg]
                <>
    (*)            
    {shape_...}={
        {st}={}  
        {ws}={}
        {in}={}
        {lr}={}
        }






-------------------------------    
    *prev*
-------------------------------
    (*)
        []
            <>
            [gs]
                <>
            [gw]
                <>
            [gg]
                <>
    (*)            
    {shape_...}={
        {st}={}  
        {ws}={}
        {in}={}
        {lr}={}
        }
-------------------------------

        {lr}={
            bare:::2fb793a::v1:'',
        }

        {st}={        
            {fs}={
                34f9654::v1:'cng_2',
            }
            {in}={
                a620541::v1:'cng_1',
            }
        }
        