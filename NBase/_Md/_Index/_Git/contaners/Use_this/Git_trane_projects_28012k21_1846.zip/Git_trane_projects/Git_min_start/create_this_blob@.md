 - {st} - (blob|ident) area :ident{stash}::blob: + :blob:
 - {fs} - (file) area :file:
 - {ws} - (ident) area :wd::file: - label on unstage file 
 - {in} - (ident) area :in::file: - label on stage file
 - {lr} - (blob|ident) area :ident{local repo}::blob: + :blob:
 - {ur} - (blob|ident) area :ident{upstr repo}::blob: + :blob:

alias gs="git status"
alias gd="git add ."
alias gp="git push -u origin master"
alias gl="git log --pretty=format:\"%h %s\" --graph"
alias gw="git show --stat --oneline HEAD"


git init


    $ git init
        Initialized empty Git repository in E:/Node_projects/Pre_Git/Start_set_1/Start_blob_1/.git/

    {shape_1}={
        {st}={}
        {fs}={}
        {ws}={}
        {in}={}
        {lr}={}
        {ur}={}
        }

## single file v1

    $ touch v1 


    {shape_1}={
        {st}={}
        {fs}={}
        {ws}={}
        {in}={}
        {lr}={}
        {ur}={}
        }
    (*)
            {{fs} lo} [touch <v1>]
                <>nothing added to commit but untracked files present (use "git add" to track)
            [gs]
            [gw]
            [gg]
    (*)   
    {shape_2}={
        {st}={}
        {fs}={
            v1:'',
        }
        {ws}={
            v1:'',
        }
        {in}={}
        {lr}={}
        {ur}={}
        }
    (*)
            {{ws} up {in}}[git add <v1>]
    (*)
    {shape_3}={
        {st}={}
        {fs}={
            v1:'',
        }
        {ws}={}
        {in}={
            v1:'',
        }
        {lr}={}
        {ur}={}
        }
    (*)
            {{in} up {lr}}
                [git commit v1 -m "empty v1"]
                    <>[master (root-commit) fc77ed4] empty v1
                    <>  1 file changed, 0 insertions(+), 0 deletions(-)
                    <>create mode 100644 v1
                [gs]
                [gw]
                [gg]

    (*) 
    {shape_4}={
        {st}={}
        {fs}={
            v1:'',
        }
        {ws}={}
        {in}={}
        {lr}={
            v1:'',
        }
        {ur}={}
        }
    (*)
        {{fs} lo}
            [echo cng_1 > v1]
            [cat v1]
                <> cng_1
            [gs]
                <> modified:   v1
            [gw]
                <>fc77ed4 (HEAD -> master) empty v1
                <>v1 | 0
            [gg]
                <>* fc77ed4 - (52 minutes ago) empty v1 - legioner9 (HEAD -> master)
    (*) 
    {shape_4}={
        {st}={}
        {fs}={
            v1:'cng_1',
        }
        {ws}={
            v1:'cng_1',
        }
        {in}={}
        {lr}={
            v1:'',
        }
        {ur}={}
        }
    (*)
        {{ws} up {in}}
            [git add v1]
    (*)
    {shape_5}={
        {st}={}
        {fs}={
            v1:'cng_1',
        }
        {ws}={}
        {in}={
            v1:'cng_1',
        }
        {lr}={
            v1:'',
        }
        {ur}={}
        }
    (*)



    
    
## * git restore --staged \<file>
        {{in} dn {wd}}
            [git restore --staged v1]
## 
    (*) 
    {shape_6}={
        {st}={}
        {fs}={
            v1:'cng_1',
        }
        {ws}={
            v1:'cng_1',
        }
        {in}={}
        {lr}={
            v1:'',
        }
        {ur}={}
        }
    (*)  


# GIT short define
## * git commit --amend
        {{in} up <prev commit>{lr}}

## 