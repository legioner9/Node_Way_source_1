    <>Saved working directory and index state WIP on master: 4016163 v1=cnt_1
    $ nothing to commit, working tree clean
    $$ dd7715f: WIP on master: 4016163 v1=cnt_1{{v1:@@@@ -1,1 -1,1 -1,0 +1,1 @@@@
                                                        -  cnt_1
                                                         - cnt_2
                                                        +++cnt_3}}
    $$ f359117: untracked files on master: 4016163 v1=cnt_1  {{fun:@@ -0,0 +1 @@
                                        +cnt_un}}   
    $$ c68567c: index on master: 4016163      v1=cnt_1 {{v1:@@ -1 +1 @@
                                                    -cnt_1
                                                    +cnt_2}}                                                                           
    $$ 4016163: master -> v1=cnt_1{{v1:@@ -1 +1 @@
                        -cnt_0
                        +cnt_1}}
    $$ 74779f5: master, remotes/bare/master -> v1=cnt_0{{v1:@@ -0,0 +1 @@
                                                        +cnt_0}}

    *-.   dd7715f - (3 minutes ago) WIP on master: 4016163 v1=cnt_1 - Legioner9 (refs/stash)
    |\ \
    | | * f359117 - (3 minutes ago) untracked files on master: 4016163 v1=cnt_1 - Legioner9
    | * c68567c - (3 minutes ago) index on master: 4016163 v1=cnt_1 - Legioner9
    |/
    * 4016163 - (33 minutes ago) v1=cnt_1 - Legioner9 (HEAD -> master)
    * 74779f5 - (14 hours ago) v1=cnt_0 - Legioner9 (bare/master)