## git stash

    git stash

    git stash save 'message'

    git stash list

    git stash apply

### --include-untracked

    git stash save -u 



