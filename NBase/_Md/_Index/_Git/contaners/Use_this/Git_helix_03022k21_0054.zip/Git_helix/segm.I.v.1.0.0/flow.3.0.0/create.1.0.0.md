[]

[echo cnt_0 > v1]
    $Untracked files: {{v1:cnt_0}}

[git add v1]
    $Changes to be committed:{{new file:   v1:cnt_0}}

        backward:[git rm --cached v1] 
                    <>rm 'v1'
                    $Untracked files: {{v1:cnt_0}}

[echo cnt_1 > v1]
    $Changes to be committed:{{new file:   v1:cnt_0}}
    $Changes not staged for commit:{{modified:   v1:cnt_1}}

        backward:[git restore v1]
                    $nothing to commit, working tree clean{{v1:cnt_0}}


[git commit -m v1=cnt_0]
    <>[master (root-commit) 74779f5] v1=cnt_0
        1 file changed, 1 insertion(+)
        create mode 100644 v1
    $ Changes not staged for commit:{{modified:   v1}}

    % not checked in to index{{v1:@@ -1 +1 @@
                                -cnt_0
                                +cnt_1}}
    * 74779f5 - (9 minutes ago) v1=cnt_0 - Legioner9 (HEAD -> master){{v1:@@ -0,0 +1 @@
        +cnt_0}}

[git add v1]
