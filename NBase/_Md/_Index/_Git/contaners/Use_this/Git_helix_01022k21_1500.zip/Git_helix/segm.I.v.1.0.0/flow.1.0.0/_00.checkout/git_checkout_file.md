    (*)            
    {shape_8}={
        {st}={}
        {fs}={
            v1:'cng_2',
        }
        {ws}={
            v1:'cng_2',
        }
        {in}={
            v1:'cng_1',
        }
        {lr}={
            bare:::2fb793a::v1:'',
        }
        {ur}={
            2fb793a::v1:'',
        }
    (*)
        {{in} dn {fs}}
            [git checkout v1]
                <>Updated 1 path from the index
                [cat v1]
                    <>cng_1
                [gs]
                    <>Changes to be committed:
                    modified:   v1
                [gw]
                    <>
                [gg]
                    <>
    (*)            
    {shape_9}={
        {st}={}
        {fs}={
            v1:'cng_1',
        }
        {ws}={
            v1:'cng_1',
        }
        {in}={
            v1:'cng_1',
        }
        {lr}={
            bare:::2fb793a::v1:'',
        }
        {ur}={
            2fb793a::v1:'',
        }


    


-------------------------------
    (*)
        {{}}
            []
                <>
                [gs]
                    <>
                [gw]
                    <>
                [gg]
                    <>
    (*)            
    {shape_...}={
        {st}={}
        {fs}={}
        {ws}={}
        {in}={}
        {lr}={}
        {ur}={}
        }
-------------------------------