    (*)            
    {shape_8}={
        {st}={}
        {fs}={
            v1:'cng_2',
        }
        {ws}={
            v1:'cng_2',
        }
        {in}={
            v1:'cng_1',
        }
        {lr}={
            bare:::2fb793a::v1:'',
        }
        {ur}={
            2fb793a::v1:'',
        }
    (*)
        {{}}
            [git checkout 2fb793a]
                <>HEAD is now at 2fb793a empty v1
                    M       v1
                [gs]
                    <>HEAD detached at 2fb793a
                    Changes to be committed:
                    modified:   v1
                    Changes not staged for commit:
                    modified:   v1
                [gw]
                    <>2fb793a (HEAD, bare/master, master) empty v1
                [gg]
                    <>* 2fb793a - (5 days ago) empty v1 - legioner9 (HEAD, bare/master, master)
            [git checkout master]
                <>Switched to branch 'master'
                    M       v1
                [gs]
                    <>On branch master
                    Changes to be committed:
                    modified:   v1
                    Changes not staged for commit:
                    modified:   v1
                [gw]
                    <>2fb793a (HEAD -> master, bare/master) empty v1
                [gg]
                    <>* 2fb793a - (5 days ago) empty v1 - legioner9 (HEAD -> master, bare/master)
    (*)            
    {shape_*prev}={
        {st}={}
        {fs}={
            v1:'cng_2',
        }
        {ws}={
            v1:'cng_2',
        }
        {in}={
            v1:'cng_1',
        }
        {lr}={
            bare:::2fb793a::v1:'',
        }
        {ur}={
            2fb793a::v1:'',
        }
    (*)

    


-------------------------------
    (*)
        {{}}
            []
                <>
                [gs]
                    <>
                [gw]
                    <>
                [gg]
                    <>
    (*)            
    {shape_...}={
        {st}={}
        {fs}={}
        {ws}={}
        {in}={}
        {lr}={}
        {ur}={}
        }
-------------------------------