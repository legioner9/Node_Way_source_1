[cat fun]
    <>cnt_un
    $ Changes to be committed:{{modified:   v1}}
    $ Changes not staged for commit:{{modified:   v1}}
    $ Untracked files:{{fun}}
    $$ not checked in to index{{@@ -1 +1 @@
                                    -cnt_2
                                    +cnt_3}}
    $$ checked in to index but not committed{{v1:@@ -1 +1 @@
                                                    -cnt_1
                                                    +cnt_2}}
    $$ 4016163: master -> v1=cnt_1{{v1:@@ -1 +1 @@
                        -cnt_0
                        +cnt_1}}
    $$ 74779f5: master, remotes/bare/master -> v1=cnt_0{{v1:@@ -0,0 +1 @@
                                                        +cnt_0}}

* 4016163 - (2 minutes ago) v1=cnt_1 - Legioner9 (HEAD -> master)
* 74779f5 - (13 hours ago) v1=cnt_0 - Legioner9 (bare/master)



------------------------------------------------------------------------------

[gh -b brn]
<>Switched to a new branch 'brn'

    $ Changes to be committed:{{modified:   v1}}
    $ Changes not staged for commit:{{modified:   v1}}
    $ Untracked files:{{fun}}
    $$ not checked in to index{{@@ -1 +1 @@
                                    -cnt_2
                                    +cnt_3}}
    $$ checked in to index but not committed{{v1:@@ -1 +1 @@
                                                    -cnt_1
                                                    +cnt_2}}
    $$ 4016163: brn, master -> v1=cnt_1{{v1:@@ -1 +1 @@
                        -cnt_0
                        +cnt_1}}
    $$ 74779f5: master, remotes/bare/master -> v1=cnt_0{{v1:@@ -0,0 +1 @@
                                                        +cnt_0}}

* 4016163 - (3 days ago) v1=cnt_1 - Legioner9 (HEAD -> brn, master)
* 74779f5 - (13 hours ago) v1=cnt_0 - Legioner9 (bare/master)

------------------------------------------------------------------------------

        remaine[gh master]
        <>
        ............
        * 4016163 - (3 days ago) v1=cnt_1 - Legioner9 (HEAD -> master, brn)


------------------------------------------------------------------------------

[gc v1 -m v1=cnt_2]
<>[brn 72890ac] v1=cnt_2
 1 file changed, 1 insertion(+), 1 deletion(-)

    $ On branch brn Untracked files:{{fun}}

    $$ f670f89: brn: -> v1=cnt_2{{v1:@@ -1 +1 @@
                                             -cnt_1
                                            +cnt_3}}

    $$ 4016163: brn, master -> v1=cnt_1{{v1:@@ -1 +1 @@
                        -cnt_0
                        +cnt_1}}
    $$ 74779f5: master, remotes/bare/master -> v1=cnt_0{{v1:@@ -0,0 +1 @@
                                                        +cnt_0}}

* f670f89 - (12 seconds ago) v1=cnt_2 - Legioner9 (HEAD -> brn)
* 4016163 - (3 days ago) v1=cnt_1 - Legioner9 (master)
* 74779f5 - (4 days ago) v1=cnt_0 - Legioner9 (bare/master)


------------------------------------------------------------------------------

        remaine[gh master]
        <>

    $ On branch ... nothing to commit, working tree clean
    $ On branch ... Changes to be committed:{{}}
    $ On branch ... Changes not staged for commit:{{}}
    $ On branch ... Untracked files:{{}}

    $$ not checked in to index{{file:}}
    $$ checked in to index but not committed{{file:}}

    $$ hash: Branch: -> Precedes:{{file:}}

------------------------------------------------------------------------------

[]
<>
    $ On branch ... nothing to commit, working tree clean
    $ On branch ... Changes to be committed:{{}}
    $ On branch ... Changes not staged for commit:{{}}
    $ On branch ... Untracked files:{{}}

    $$ not checked in to index{{file:}}
    $$ checked in to index but not committed{{file:}}

    $$ hash: Branch: -> Precedes:{{file:}}

------------------------------------------------------------------------------

[]
<>
    $ On branch ... nothing to commit, working tree clean
    $ On branch ... Changes to be committed:{{}}
    $ On branch ... Changes not staged for commit:{{}}
    $ On branch ... Untracked files:{{}}

    $$ not checked in to index{{file:}}
    $$ checked in to index but not committed{{file:}}

    $$ hash: Branch: -> Precedes:{{file:}}
