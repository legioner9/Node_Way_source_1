# Changelog

## [Unreleased][unreleased]

To be released in 1.0.0

- Watch directories recursive
- Rebuild recursive when new directories found or old directories remove
- Deduplicate events with debounce

[unreleased]: https://github.com/metarhia/metawatch/compare/c0e37f8...HEAD
