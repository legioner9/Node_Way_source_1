# Deep nested directories watch for node.js

[![CI Status](https://github.com/metarhia/metawatch/workflows/Testing%20CI/badge.svg)](https://github.com/metarhia/metawatch/actions?query=workflow%3A%22Testing+CI%22+branch%3Amaster)
[![NPM Version](https://badge.fury.io/js/metawatch.svg)](https://badge.fury.io/js/metawatch)
[![NPM Downloads/Month](https://img.shields.io/npm/dm/metawatch.svg)](https://www.npmjs.com/package/metawatch)
[![NPM Downloads](https://img.shields.io/npm/dt/metawatch.svg)](https://www.npmjs.com/package/metawatch)

- Watch directories recursive
- Rebuild recursive when new directories found or old directories remove
- Deduplicate events with debounce
