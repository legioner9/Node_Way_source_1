'use strict';

module.exports = {
  presets: ['@babel/env'],
};
