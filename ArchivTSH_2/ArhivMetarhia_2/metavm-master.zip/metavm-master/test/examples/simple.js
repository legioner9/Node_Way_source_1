({
  field: 'value',

  add(a, b) {
    return a + b;
  },

  sub: (a, b) => a - b,
});
