# Changelog

## [Unreleased][unreleased]

To be released in 1.0.0

- Simple query builder instead of SQL clause generator
- Only PostgreSQL support instead of universal
- Database schema loader
- PostgreSQL DDL script generator
- TypeScript typings generator
- Calculate changec and generate up and down migrations

## [metarhia-sql][] - 2020-09-06

Code before fork from https://github.com/metarhia/sql

[unreleased]: https://github.com/metarhia/metasql/compare/metarhia-sql...HEAD
[metarhia-sql]: https://github.com/metarhia/metasql/tree/metarhia-sql
