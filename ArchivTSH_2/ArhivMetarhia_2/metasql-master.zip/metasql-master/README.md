# MetaSQL schema generator, migrations and query builder

[![CI Status](https://github.com/metarhia/metasql/workflows/Testing%20CI/badge.svg)](https://github.com/metarhia/metasql/actions?query=workflow%3A%22Testing+CI%22+branch%3Amaster)
[![NPM Version](https://badge.fury.io/js/metasql.svg)](https://badge.fury.io/js/metasql)
[![NPM Downloads/Month](https://img.shields.io/npm/dm/metasql.svg)](https://www.npmjs.com/package/metasql)
[![NPM Downloads](https://img.shields.io/npm/dt/metasql.svg)](https://www.npmjs.com/package/metasql)
