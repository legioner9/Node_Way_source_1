({
  name: { type: 'string', unique: true },
});
