({
  city: 'City',
  name: 'string',
});
