({
  planet: 'Planet',
  name: { type: 'string', unique: true },
});
