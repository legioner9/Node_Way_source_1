({
  point: 'geometry(Point, 4326)',
});
