({
  CompanyCity: 'global relation',

  company: 'Company',
  city: 'City',

  companyCity: { primary: ['company', 'city'] },
});
