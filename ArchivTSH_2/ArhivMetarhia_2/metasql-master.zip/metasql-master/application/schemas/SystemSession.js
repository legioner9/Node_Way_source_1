({
  SystemSession: 'system entity',

  user: 'SystemUser',
  token: { type: 'string', unique: true },
  ip: 'string',
  data: 'json',
});
