({
  District: 'global dictionary',

  city: 'City',
  name: { type: 'string', unique: true },
});
