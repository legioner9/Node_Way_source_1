({
  creator: 'SystemUser',
  author: 'SystemUser',
  createTime: 'datetime',
  updateTime: 'datetime',
});
