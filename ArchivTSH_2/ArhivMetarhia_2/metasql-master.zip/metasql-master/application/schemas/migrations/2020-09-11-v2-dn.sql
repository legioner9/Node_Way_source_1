DROP TABLE "District";

ALTER TABLE "Country" DROP COLUMN "planetId";

DROP TABLE "Planet";
