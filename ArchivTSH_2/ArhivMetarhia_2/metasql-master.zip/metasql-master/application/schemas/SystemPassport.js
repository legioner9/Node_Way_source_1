({
  SystemPassport: 'system entity',

  number: { type: 'string', unique: true },
  issue: 'date',
});
