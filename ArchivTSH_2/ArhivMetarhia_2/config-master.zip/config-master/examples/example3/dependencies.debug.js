({
  internal: ['fs', 'path', 'http', 'v8', 'timers'],
  external: ['@metarhia/common', 'metasync', 'eslint'],
});
