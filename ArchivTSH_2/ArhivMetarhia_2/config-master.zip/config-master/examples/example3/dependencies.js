({
  internal: ['fs', 'path', 'http'],
  external: ['@metarhia/common'],
});
