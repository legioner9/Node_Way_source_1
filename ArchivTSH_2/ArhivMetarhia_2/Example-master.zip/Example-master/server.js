'use strict';

require('impress');
