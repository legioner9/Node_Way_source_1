({
  access: 'public',
  method: application.introspect
});
