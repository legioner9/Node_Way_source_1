({
  interval: 30000,
  active: false,
});
