({
  url: 'ws://localhost:8001', // TLS doesn't support IP for host. See: RFC 6066
  interfaces: ['example'],
});
