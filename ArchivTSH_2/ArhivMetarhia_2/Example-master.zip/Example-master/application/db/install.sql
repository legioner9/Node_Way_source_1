CREATE USER marcus WITH PASSWORD 'marcus';
CREATE DATABASE application OWNER marcus;
