# Metarhia

Experimental technological stack, including:

- Application Server [Impress](https://github.com/metarhia/Impress)
- Client Run-time [Console](https://github.com/metarhia/Console)
- JavaScript Transfer Protocol [JSTP](https://github.com/metarhia/JSTP)
- Database Management System [GlobalStorage](https://github.com/metarhia/GlobalStorage)

See [Metarhia packages/repositories maintainers](https://github.com/metarhia/Metarhia/blob/master/doc/maintainers.md)
