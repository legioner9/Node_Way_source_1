# Metarhia

Это стек технологий, включающий:

- Сервер приложений [Impress](https://github.com/metarhia/Impress)
- Браузер приложений и баз данных [Console](https://github.com/metarhia/Console)
- Многоцелевой протокол [JSTP](https://github.com/metarhia/JSTP)
- Распределенная СУБД [GlobalStorage](https://github.com/metarhia/GlobalStorage)
