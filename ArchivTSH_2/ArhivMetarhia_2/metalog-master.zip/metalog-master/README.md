# Meta Logger for Metarhia

[![CI Status](https://github.com/metarhia/metalog/workflows/Testing%20CI/badge.svg)](https://github.com/metarhia/metalog/actions?query=workflow%3A%22Testing+CI%22+branch%3Amaster)
[![codacy](https://api.codacy.com/project/badge/Grade/7aaad5ed17c74634855fa6202a03a56e)](https://www.codacy.com/app/metarhia/metalog)
[![npm version](https://img.shields.io/npm/v/metalog.svg?style=flat)](https://www.npmjs.com/package/metalog)
[![npm downloads/month](https://img.shields.io/npm/dm/metalog.svg)](https://www.npmjs.com/package/metalog)
[![npm downloads](https://img.shields.io/npm/dt/metalog.svg)](https://www.npmjs.com/package/metalog)
[![license](https://img.shields.io/badge/license-MIT-blue.svg)](https://github.com/metarhia/metalog/blob/master/LICENSE)

## Installation

```bash
$ npm install metalog
```

## Contributors

- Timur Shemsedinov <timur.shemsedinov@gmail.com>
- See github for full [contributors list](https://github.com/metarhia/metalog/graphs/contributors)

## License

Copyright (c) 2017-2020 Metarhia contributors.
Metalog is [MIT licensed](./LICENSE).
