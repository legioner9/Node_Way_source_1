({
  size: '50mb', // memory cache size
  maxFileSize: '10mb', // max file size to cache
});
