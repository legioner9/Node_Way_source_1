({
  // Cloud configuration
  cloud: 'PrivateCloud', // cloud name
  server: '1', // Server binary prefix Id
  instance: 'standalone', // cloud instance type: standalone, controller, server
  key: 'ap14-me0b/6jtl9i:8d7$k8901d556*g', // Cloud access key
  gc: 1 * 60 * 60 * 1000, // garbage collector interval
});
