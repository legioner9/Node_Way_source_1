# Changelog

## [Unreleased][unreleased]

## [1.0.0][] - 2020-12-16

- Reflect data structures to template with tick syntax

## [0.0.x][] Pre-release versions

[unreleased]: https://github.com/metarhia/tickplate/compare/v1.0.0...HEAD
[1.0.0]: https://github.com/metarhia/tickplate/compare/v0.0.x...v1.0.0
[0.0.x]: https://github.com/metarhia/tickplate/releases/tag/v0.0.x
