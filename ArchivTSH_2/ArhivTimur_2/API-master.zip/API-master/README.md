## Application Interface with abstract Transport

[![Разработка API на Node.js](https://img.youtube.com/vi/-az912XBCu8/0.jpg)](https://www.youtube.com/watch?v=-az912XBCu8)
