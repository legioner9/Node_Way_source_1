# Different types of Associative Collections

[![Коллекции, множества, хештаблицы](https://img.youtube.com/vi/hN0wsq5LNOc/0.jpg)](https://www.youtube.com/watch?v=hN0wsq5LNOc)
