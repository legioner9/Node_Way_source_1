# Data structures projection
[![Проекции и отображения наборов данных](https://img.youtube.com/vi/lwJCq9inky8/0.jpg)](https://www.youtube.com/watch?v=lwJCq9inky8)
