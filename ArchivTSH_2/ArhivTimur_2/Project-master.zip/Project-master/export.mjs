'use strict';

const field = 'value';
const func = () => {};

export { field, func };
