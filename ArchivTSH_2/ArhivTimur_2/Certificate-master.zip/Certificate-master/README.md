# Certificates of Qualification in Software Engineering

| Level      | 2015 | 2016 | 2017 | 2018 | 2019 | 2020 |
| ---------- | ---- | ---- | ---- | ---- | ---- | ---- |
| Basics     |      |      |      |      |      |      |
| Advanced   |      |      |      |      | [3](2-Advanced/2019/README.md) | [2](2-Advanced/2020/README.md) |
| Specialist |      |      |      |      |      |      |
| Expert     |      |      |      |      |      |      |
| Lecturer   |      |      |      |      |      |      |
