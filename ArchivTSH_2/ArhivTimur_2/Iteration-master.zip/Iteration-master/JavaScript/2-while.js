'use strict';

let a = 0;
while (a < 10) {
  console.log(a++);
}
