# Partial function application and Currying

[![Композиция, каррирование, частичное применение](https://img.youtube.com/vi/ND8KQ5xjk7o/0.jpg)](https://www.youtube.com/watch?v=ND8KQ5xjk7o)

[Exercises](Exercises.en.md)
