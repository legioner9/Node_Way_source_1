'use strict';

// Define function power - an alias to Math.pow().
const power = null;

// Implement function `square(n)`, which returns square of its argument.
// The function may or may not reuse function `power`.
const square = null;

// Implement function `cube(n)` using partial application
// The function should return power of three for the given argument.
const cube = null;

module.exports = { power, square, cube };
