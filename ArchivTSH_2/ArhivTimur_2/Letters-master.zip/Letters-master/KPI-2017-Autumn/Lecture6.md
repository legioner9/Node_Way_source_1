# Лекции #6 "Композиция функций, частичное применение, обертки"

### Примеры кода
- [Композиция функций](https://github.com/HowProgrammingWorks/Composition)
- [Частичное применение функций](https://github.com/HowProgrammingWorks/PartialApplication)
- Каррирование функций (см. в репозитории с частичным применением)
- [Функции-обертки](https://github.com/HowProgrammingWorks/Wrapper)
- [Примеры императивного и функционального кода](https://github.com/HowProgrammingWorks/Abstractions)
