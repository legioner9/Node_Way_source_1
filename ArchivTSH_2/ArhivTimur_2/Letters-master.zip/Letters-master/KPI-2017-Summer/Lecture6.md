# Лекция 6: Файлы, потоки и буферы, и фронтенд

Краткий план со ссылками на примеры кода:

- [Работа с файлами](https://github.com/HowProgrammingWorks/Files)
- [Буферы](https://github.com/HowProgrammingWorks/Buffers)
- [Файловые потоки](https://github.com/HowProgrammingWorks/Streams)
