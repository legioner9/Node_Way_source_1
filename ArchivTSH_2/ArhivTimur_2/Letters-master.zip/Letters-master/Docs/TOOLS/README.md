# Инструментарий разработчика

- [Node.js](https://nodejs.org/en/download/current/) для Linux, MacOS и Windows. Или скрипты автоматического развертывания для [Fedora, CentOS, Debian, Ubuntu](https://github.com/metarhia/Impress/tree/master/deploy) из бинарноков без префикса, а из исходников с префиксом `-src.sh`
- [MongoDB](https://www.mongodb.com/download-center) для 

