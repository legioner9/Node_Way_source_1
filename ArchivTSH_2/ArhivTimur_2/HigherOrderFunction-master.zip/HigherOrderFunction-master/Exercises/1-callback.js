'use strict';

const iterate = (obj, callback) => null;

module.exports = { iterate };
