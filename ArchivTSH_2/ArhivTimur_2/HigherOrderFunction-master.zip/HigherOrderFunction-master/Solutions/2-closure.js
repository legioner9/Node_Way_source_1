'use strict';

const store = x => () => x;

module.exports = { store };
