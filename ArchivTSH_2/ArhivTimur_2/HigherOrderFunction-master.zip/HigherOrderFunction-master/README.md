# Higher-order functions having functions as arguments or result

[![Функции высшего порядка, колбеки, события](https://img.youtube.com/vi/1vqATwbGHnc/0.jpg)](https://www.youtube.com/watch?v=1vqATwbGHnc)
