# Proxy

[![Использование Proxy и Symbol](https://img.youtube.com/vi/UjZjSDyi9AM/0.jpg)](https://www.youtube.com/watch?v=UjZjSDyi9AM)
