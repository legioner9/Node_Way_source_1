## Association, Aggregation and Composition

[![Ассоциация, агрегация и композиция объектов в JavaScript](https://img.youtube.com/vi/tOIcBrzezK0/0.jpg)](https://www.youtube.com/watch?v=tOIcBrzezK0)
