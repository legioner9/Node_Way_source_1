'use strict';

module.exports = { f: null, g: undefined };
