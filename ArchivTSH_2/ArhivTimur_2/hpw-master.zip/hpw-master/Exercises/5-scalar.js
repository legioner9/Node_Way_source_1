'use strict';

let name = 'Marcus Aurelius';

module.exports = { name };
