# Laboratory Work for How.Programming.Works Project

Install:
1. Create empty folder
2. In this folder run `npm install hpw`
3. Follow instructions
