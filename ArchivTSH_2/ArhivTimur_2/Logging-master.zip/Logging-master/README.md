## Logging

[![Логирование на Node.js / Logging in JavaScript](https://img.youtube.com/vi/4DkZj2Cdokc/0.jpg)](https://www.youtube.com/watch?v=4DkZj2Cdokc)

