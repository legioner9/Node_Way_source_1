'use strict';

const createUser = (name, city) => ({ name, city });

module.exports = { createUser };
