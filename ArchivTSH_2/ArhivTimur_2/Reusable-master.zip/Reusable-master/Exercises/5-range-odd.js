'use strict';

const rangeOdd = null;

module.exports = { rangeOdd };
