## «Why Testing» in examples

[![Тестирование: юниттесты в JavaScript](https://img.youtube.com/vi/CszugIag2TA/0.jpg)](https://www.youtube.com/watch?v=CszugIag2TA)
