# Data Collectors for Asynchronous Programming
[![Асинхронные коллекторы данных](https://img.youtube.com/vi/tgodt1JL6II/0.jpg)](https://www.youtube.com/watch?v=tgodt1JL6II)
