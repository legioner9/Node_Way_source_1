# AsyncAwait
[![Асинхронные функции async, await, thenable, обработка ошибок](https://img.youtube.com/vi/Jdf_tZuJbHI/0.jpg)](https://www.youtube.com/watch?v=Jdf_tZuJbHI)
