'use strict';

{
  const array = [127, 0, 0, 1];
  console.log(array.join('.'));
}
