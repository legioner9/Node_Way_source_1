'use strict';

{
  const array = [10, 20, 30, 40];
  console.log(array.find(x => x > 25));
}
{
  const array = [10, 20, 30, 40];
  console.log(array.findIndex(x => x > 25));
}
