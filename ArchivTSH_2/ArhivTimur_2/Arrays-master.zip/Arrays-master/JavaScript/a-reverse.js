'use strict';

{
  const array = [1, 0, 0, 127];
  console.log(array.reverse().join('.'));
}
