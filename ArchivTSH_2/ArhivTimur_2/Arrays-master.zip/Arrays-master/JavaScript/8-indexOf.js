'use strict';

{
  const array = [1, 2, 2, 1];
  console.log(array.indexOf(2));
}
{
  const array = [1, 2, 2, 1];
  console.log(array.lastIndexOf(2));
}
{
  const array = [1, 2, 2, 1];
  console.log(array.indexOf(20));
}
