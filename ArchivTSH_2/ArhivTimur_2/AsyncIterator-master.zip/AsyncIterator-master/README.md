## Asynchronous Iterator and Iterable protocols

[![Итераторы и асинхронные итераторы в JavaScript](https://img.youtube.com/vi/rBGFlWpVpGs/0.jpg)](https://www.youtube.com/watch?v=rBGFlWpVpGs)
