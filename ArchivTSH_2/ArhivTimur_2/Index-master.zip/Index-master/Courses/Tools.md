# Инструменты разработки и жизненного цикла ПО

- [Настройка среды: Node.js, npm, git, eslint](https://youtu.be/hSyA7tcNaCE)
- Непрерывная интеграция
- Компиляция, интерпретация, оптимизация
- Системы контроля версий и пакетные менеджеры
- IDE, RAD
- CLI - command-line interface tools
- Бенчмаркинг
  - [Измерение производительности кода и оптимизация в JavaScript и Node.js](https://youtu.be/sanq2X7Re8o)
  - https://github.com/HowProgrammingWorks/Benchmark
