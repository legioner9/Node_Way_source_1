# Высоконагруженные и масштабируемые системы

- [Высоконагруженные распределенные приложения на Node.js](https://youtu.be/7tfZDABPvVs)
- [Serverless Clouds (FaaS) и изоляция контекстов запросов в Node.js](https://youtu.be/x-Rd6fPV6L8)
  - Слайды: https://www.slideshare.net/tshemsedinov/serverless-clouds-faas-and-request-context-isolation-in-nodejs
