# Операционные системы

- [Межпроцессовое взаимодействие в Node.js](https://youtu.be/2OXWZFMvfbc)
  - Примеры кода: https://github.com/HowProgrammingWorks/InterProcessCommunication
