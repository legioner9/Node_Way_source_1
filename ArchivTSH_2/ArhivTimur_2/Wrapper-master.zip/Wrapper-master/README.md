# Wrapper functions, Interface wrappers, etc.

[![Функции-обертки: Wrappers в JavaScript](https://img.youtube.com/vi/En7pWi2fSzs/0.jpg)](https://www.youtube.com/watch?v=En7pWi2fSzs)
